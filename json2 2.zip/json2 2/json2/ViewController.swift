//
//  ViewController.swift
//  json2
//
//  Created by MACOS on 6/15/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITabBarDelegate,UITableViewDataSource {
    var finalarr : [Any] = [];

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = URL(string: "https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20cricket.news%20%20where%20region%3D%22in%22&format=json&diagnostics=true&env=store%3A%2F%2F0TxIGQMQbObzvU4Apia0V0&callback=")
        do{
        
        let data =  try Data(contentsOf: url!)
            do{
                let dic = try JSONSerialization.jsonObject(with: data, options: [])as! [String : Any]
                
                let dic1 = dic["query"] as! [String : Any]
                let results = dic1["results"] as! [String : Any]
                let item = results["item"] as! [[String : Any]]
                
                for it in item{
                    var temp : [String] = []
                    temp.append(it["author"]as!String)
                    temp.append(it["link"]as!String)
                    temp.append(it["title"]as!String)
                    finalarr.append(temp)
                }
            }
            catch{}
            
            
        }
        
        catch{}
        print(finalarr)
        
        
        // Do any additional setup after loading the view, typically from a nib.
        }
    func numberOfSections(in tableView: UITableView) -> Int {
        return finalarr.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        var temp = finalarr[indexPath.section] as! [String]
        cell.textLabel?.text = temp[indexPath.row]
        return cell
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

